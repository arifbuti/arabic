package com.cloudstream.plugins

import com.lagradost.cloudstream3.*
import com.lagradost.cloudstream3.model.*
import com.lagradost.cloudstream3.utils.*
import org.jsoup.Jsoup

class TopCinema : MainAPI() {
    override var name = "TopCinema"
    override var mainUrl = "https://web6.topcinema.cam"
    override var lang = "ar"
    override var hasMainPage = true

    override suspend fun getMainPage(): List<MainPageResponse> {
        val document = app.get(mainUrl).document
        val sections = mutableListOf<MainPageResponse>()
        document.select("div.category-block").forEach {
            val genre = it.selectFirst("h3")?.text() ?: return@forEach
            val items = it.select("div.item").mapNotNull { el ->
                val a = el.selectFirst("a[href]") ?: return@mapNotNull null
                val title = a.text()
                val href = a.absUrl("href")
                val poster = el.selectFirst("img")?.absUrl("src")
                MovieSearchResponse(title, href, poster)
            }
            sections.add(MainPageResponse(genre, items))
        }
        return sections
    }

    override suspend fun search(query: String): List<SearchResponse> {
        val doc = app.get("$mainUrl/?s=$query").document
        return doc.select("div.search-item").mapNotNull {
            val a = it.selectFirst("a[href]") ?: return@mapNotNull null
            val title = a.text()
            val href = a.absUrl("href")
            val poster = it.selectFirst("img")?.absUrl("src")
            MovieSearchResponse(title, href, poster)
        }
    }

    override suspend fun load(url: String): LoadResponse {
        val doc = app.get(url).document
        val title = doc.selectFirst("h1")?.text() ?: "غير معروف"
        val poster = doc.selectFirst(".poster img")?.absUrl("src")
        val isMovie = doc.selectFirst(".movie-info") != null
        val episodes = if (isMovie) {
            listOf(Episode(1, title, url))
        } else {
            doc.select(".episodes-list a").mapIndexed { i, el ->
                Episode(i + 1, el.text(), el.absUrl("href"))
            }
        }
        return MovieLoadResponse(title, url, this.name, poster ?: "", episodes)
    }

    override suspend fun loadLinks(
        episode: Episode,
        subtitleCallback: SubtitleCallback,
        callback: (ExtractorLink) -> Unit
    ): Boolean {
        val doc = app.get(episode.url).document
        val iframeSrc = doc.selectFirst("iframe")?.absUrl("src") ?: return false
        callback(
            ExtractorLink(
                name = "TopCinema",
                source = iframeSrc,
                url = iframeSrc,
                quality = Qualities.Unknown.value,
                isM3u8 = true
            )
        )
        return true
    }
}
